﻿using System;

namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i;
            const int tama = 5;
            string[] cursos = new string[tama];

            Console.WriteLine("*** Cursos Técnicos ***\n");

            cursos = cadastroCursos();

            Console.WriteLine("\n *** cursos cadastrados no Vetor ***\n");
            for (int x = 0; x < cursos.Length; x++)
                Console.WriteLine("{0}º Curso: {1}", x + 1, cursos[x]);

            Console.ReadKey();
        }

        static string[] cadastroCursos()
        {
            string[] vetorAuxiliar = new string[5];
            for (int x = 0; x < 5; x++)
            {
                Console.Write("Digite o nome do {0}º Curso: ", x + 1);
                vetorAuxiliar[x] = Console.ReadLine();
            }
            return vetorAuxiliar;
        }
    }
}