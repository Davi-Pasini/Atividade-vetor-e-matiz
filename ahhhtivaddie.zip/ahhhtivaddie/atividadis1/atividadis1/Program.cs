﻿using System;

namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string n1, n2, n3, n4, n5, n6, n7, n8, n9, n10;

            Console.WriteLine("DIgite o 1º nome: "); n1 = Console.ReadLine();
            Console.WriteLine("DIgite o 2º nome: "); n2 = Console.ReadLine();
            Console.WriteLine("DIgite o 3º nome: "); n3 = Console.ReadLine();
            Console.WriteLine("DIgite o 4º nome: "); n4 = Console.ReadLine();
            Console.WriteLine("DIgite o 5º nome: "); n5 = Console.ReadLine();
            Console.WriteLine("DIgite o 6º nome: "); n6 = Console.ReadLine();
            Console.WriteLine("DIgite o 7º nome: "); n7 = Console.ReadLine();
            Console.WriteLine("DIgite o 8º nome: "); n8 = Console.ReadLine();
            Console.WriteLine("DIgite o 9º nome: "); n9 = Console.ReadLine();
            Console.WriteLine("DIgite o 10º nome: "); n10 = Console.ReadLine();

            Console.WriteLine();

            Console.WriteLine("1° nome: " + n1);
            Console.WriteLine("2° nome: " + n2);
            Console.WriteLine("3° nome: " + n3);
            Console.WriteLine("4° nome: " + n4);
            Console.WriteLine("5° nome: " + n5);
            Console.WriteLine("6° nome: " + n6);
            Console.WriteLine("7° nome: " + n7);
            Console.WriteLine("8° nome: " + n8);
            Console.WriteLine("9° nome: " + n9);
            Console.WriteLine("10° nome: " + n10);

            Console.ReadKey();
        }
    }
}