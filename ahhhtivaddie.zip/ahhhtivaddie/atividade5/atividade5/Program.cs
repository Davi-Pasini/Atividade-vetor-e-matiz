﻿using System;

namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i;
            const int tam = 10;
            string[] times = new string[tam];

            Console.WriteLine("*** Times de Futebol***\n");

            for (i = 0; i < tam; i++)
            {
                Console.Write("nome do {0}º time: ", 1 + i);
                times[i] = Console.ReadLine();
            }
            Console.WriteLine("\n *** Times cadastros no Vetor ***\n");
            exibirDados(times);

            Console.ReadLine();
        }
        static void exibirDados(string[] t)
        {

            for (int x = 0; x < t.Length; x++)
                Console.WriteLine("{0}º time: {1}", x+1, t[x]);
        }
    }
}